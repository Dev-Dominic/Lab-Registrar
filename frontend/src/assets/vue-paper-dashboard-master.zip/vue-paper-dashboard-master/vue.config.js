module.exports = {
  lintOnSave: false
};
